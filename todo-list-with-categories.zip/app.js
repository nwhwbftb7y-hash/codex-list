const STORAGE_KEY = "today-todos-v1";

const form = document.querySelector("#todo-form");
const input = document.querySelector("#todo-input");
const list = document.querySelector("#todo-list");
const template = document.querySelector("#todo-template");
const emptyState = document.querySelector("#empty-state");
const itemsLeft = document.querySelector("#items-left");
const clearCompleted = document.querySelector("#clear-completed");
const progressRing = document.querySelector("#progress-ring");
const progressValue = document.querySelector("#progress-value");
const dateLabel = document.querySelector("#date-label");
const exportData = document.querySelector("#export-data");
const importData = document.querySelector("#import-data");
const importFile = document.querySelector("#import-file");

const CATEGORIES = {
  "urgent-important": { label: "紧急重要" },
  important: { label: "重要不紧急" },
  low: { label: "不紧急不重要" },
};

let todos = loadTodos();
let currentFilter = "all";

dateLabel.textContent = new Intl.DateTimeFormat("zh-CN", {
  month: "long",
  day: "numeric",
  weekday: "long",
}).format(new Date());

function loadTodos() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY)) ?? [];
    return saved.map((todo) => ({ ...todo, category: CATEGORIES[todo.category] ? todo.category : "important" }));
  } catch {
    return [];
  }
}

function saveTodos() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(todos));
}

function visibleTodos() {
  if (currentFilter === "active") return todos.filter((todo) => !todo.completed);
  if (currentFilter === "completed") return todos.filter((todo) => todo.completed);
  return todos;
}

function render() {
  list.replaceChildren();

  visibleTodos().forEach((todo) => {
    const fragment = template.content.cloneNode(true);
    const item = fragment.querySelector(".todo-item");
    const toggle = fragment.querySelector(".toggle");
    const remove = fragment.querySelector(".delete");
    const badge = fragment.querySelector(".category-badge");

    item.dataset.id = todo.id;
    item.classList.toggle("completed", todo.completed);
    fragment.querySelector(".todo-text").textContent = todo.text;
    badge.textContent = CATEGORIES[todo.category].label;
    badge.dataset.category = todo.category;
    toggle.setAttribute("aria-label", todo.completed ? "标记为未完成" : "标记为已完成");

    toggle.addEventListener("click", () => toggleTodo(todo.id));
    remove.addEventListener("click", () => deleteTodo(todo.id));
    list.append(fragment);
  });

  const activeCount = todos.filter((todo) => !todo.completed).length;
  const completedCount = todos.length - activeCount;
  const progress = todos.length ? Math.round((completedCount / todos.length) * 100) : 0;

  emptyState.hidden = visibleTodos().length > 0;
  itemsLeft.textContent = `${activeCount} 件待完成`;
  clearCompleted.disabled = completedCount === 0;
  progressValue.textContent = `${progress}%`;
  progressRing.style.setProperty("--progress", `${progress * 3.6}deg`);
  progressRing.setAttribute("aria-label", `完成进度 ${progress}%`);
}

function addTodo(text, category) {
  todos.unshift({ id: crypto.randomUUID(), text, category, completed: false });
  saveTodos();
  render();
}

function toggleTodo(id) {
  todos = todos.map((todo) => todo.id === id ? { ...todo, completed: !todo.completed } : todo);
  saveTodos();
  render();
}

function deleteTodo(id) {
  todos = todos.filter((todo) => todo.id !== id);
  saveTodos();
  render();
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const text = input.value.trim();
  if (!text) {
    input.focus();
    return;
  }
  const category = new FormData(form).get("category");
  addTodo(text, category);
  input.value = "";
  input.focus();
});

document.querySelectorAll(".filter").forEach((button) => {
  button.addEventListener("click", () => {
    currentFilter = button.dataset.filter;
    document.querySelectorAll(".filter").forEach((item) => item.classList.toggle("active", item === button));
    render();
  });
});

clearCompleted.addEventListener("click", () => {
  todos = todos.filter((todo) => !todo.completed);
  saveTodos();
  render();
});

exportData.addEventListener("click", () => {
  const backup = JSON.stringify({ version: 1, exportedAt: new Date().toISOString(), todos }, null, 2);
  const url = URL.createObjectURL(new Blob([backup], { type: "application/json" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = `todo-backup-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  URL.revokeObjectURL(url);
});

importData.addEventListener("click", () => importFile.click());

importFile.addEventListener("change", async () => {
  const file = importFile.files[0];
  if (!file) return;

  try {
    const backup = JSON.parse(await file.text());
    if (!Array.isArray(backup.todos)) throw new Error("invalid backup");
    const restored = backup.todos
      .filter((todo) => typeof todo.text === "string" && todo.text.trim())
      .map((todo) => ({
        id: todo.id || crypto.randomUUID(),
        text: todo.text.trim().slice(0, 100),
        completed: Boolean(todo.completed),
        category: CATEGORIES[todo.category] ? todo.category : "important",
      }));
    if (!confirm(`将用备份中的 ${restored.length} 个任务替换当前列表，是否继续？`)) return;
    todos = restored;
    saveTodos();
    render();
  } catch {
    alert("无法导入：请选择由本页面导出的 JSON 备份文件。");
  } finally {
    importFile.value = "";
  }
});

render();
